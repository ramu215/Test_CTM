# Hello World Application

## Building Image

* switch to project directory and run `mvn spring-boot:build-image`. This will build an image `docker.io/library/helloworld:1.0.0`
    * you can verify this with `docker images | grep helloworld` from bash shell.  
* you can run this app with `docker run -p8080:8080 docker.io/library/helloworld:1.0.0`
* open browser and enter `http://localhost:8080/hello-world/greet` and you should get the below json response with a fresh time stamp for every request on that endpoint.
```javascript
{"message": "hello-world", "time": "2021-05-21T20:23:36.210626Z"}
```

## Prometheus 

* switch to project directory and run `docker-compse up -d`
* this should bring up both the cicddemo spring boot app and prometheus.
* the spring boot app is already configured to export metrics and prometheus container is configured to scrape periodically from the same.   
* to look at prometheus go to `localhost:9090/targets`
* this should tell you that its scraping metrics from `http://cicddemo:8080/actuator/prometheus`
* now go to `localhost:9090/graph` and search for any metrics like 
  * `process_cpu_usage` or `http_server_requests_seconds_max` and look at the graph view  
  
## Grafana

* goto `http:localhost:3000` and login with the default admin:admin username password into grafana.
* Add the prometheus `http://localhost:3000/datasources/new?utm_source=grafana_gettingstarted`
* Choose the below options for the data base configuration
  * http url use : http://localhost:9090
  * access : Browser
  * Http Method : GET
* Save and Test and go back click the `+` sign on the menu and import dashboard enter this url `https://grafana.com/grafana/dashboards/4701`