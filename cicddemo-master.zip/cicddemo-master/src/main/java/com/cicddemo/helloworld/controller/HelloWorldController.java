package com.cicddemo.helloworld.controller;

import com.cicddemo.helloworld.model.Greeting;
import io.micrometer.core.annotation.Timed;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@RestController
@RequestMapping(value = "hello-world")
@Timed
public class HelloWorldController {

    @GetMapping(value = "greet")
    public Greeting greet() {
        return Greeting.builder().message("hello-world").time(Instant.now()).build();
    }
}
